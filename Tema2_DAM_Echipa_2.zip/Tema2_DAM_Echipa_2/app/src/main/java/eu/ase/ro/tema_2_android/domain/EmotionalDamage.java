package eu.ase.ro.tema_2_android.domain;

public enum EmotionalDamage {
    USOR, MODERAT, SEVER
}
