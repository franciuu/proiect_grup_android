package eu.ase.ro.tema_2_android.domain;

public enum LossLevel {
    MICI, MEDII, MARI
}
